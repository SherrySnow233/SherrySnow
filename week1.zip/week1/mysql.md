# mysql

打开mysql 官网，MYSQL community downloads下载大约300多兆。下载完成后安装，需要设置密码，设置完成后输入密码登录即可.数据库连接：点击connections下方的灰色区域，输入密码即可进入。

<img src="C:\Users\ThinkPad\研究生上课材料\研一下\数据库原理\作业\作业week1\pictures\1.png" style="zoom:33%;" />

MySQL是一种复杂的程序。它的所有命令必须通过命令行输入；且它不提供可视化界面。

点击加号，建立链接

![](C:\Users\ThinkPad\研究生上课材料\研一下\数据库原理\作业\作业week1\pictures\2.png)

输入connection name 和账号密码即可创建新数据库，由于我的账号密码已经存储在电脑中了，所以只需输入connection name。

![](C:\Users\ThinkPad\研究生上课材料\研一下\数据库原理\作业\作业week1\pictures\3.png)

建好之后，数据库会显示在主页上，双击，输入密码即可进入

![](C:\Users\ThinkPad\研究生上课材料\研一下\数据库原理\作业\作业week1\pictures\3'.png)

接下来我想在数据库中建表，于是点击了相应按钮，出现了如下提示

![](C:\Users\ThinkPad\研究生上课材料\研一下\数据库原理\作业\作业week1\pictures\4.png)

所以我需要先建立一个schema，名称为“HOMEWORK”，点击apply 出现如下提示，意思就是schema和table名称只能小写。Fine.

![](C:\Users\ThinkPad\研究生上课材料\研一下\数据库原理\作业\作业week1\pictures\5.png)

接下来建表。

![](C:\Users\ThinkPad\研究生上课材料\研一下\数据库原理\作业\作业week1\pictures\6.png)

右击“table”点击新建出现以下界面

![](C:\Users\ThinkPad\研究生上课材料\研一下\数据库原理\作业\作业week1\pictures\7.png)

![](C:\Users\ThinkPad\研究生上课材料\研一下\数据库原理\作业\作业week1\pictures\8.png)

![](C:\Users\ThinkPad\研究生上课材料\研一下\数据库原理\作业\作业week1\pictures\9.png)

出现错误，不知道为什么，积极寻求答案和帮助未果。






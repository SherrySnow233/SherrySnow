## sqlite

![](C:\Users\ThinkPad\研究生上课材料\研一下\数据库原理\作业\作业week1\pictures\10.png)

下载之后不知道跑到哪里去了只显示此扩展已安装到所有适用产品。

![](C:\Users\ThinkPad\研究生上课材料\研一下\数据库原理\作业\作业week1\pictures\11.png)